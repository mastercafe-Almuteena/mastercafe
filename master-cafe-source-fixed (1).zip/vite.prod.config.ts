import { defineConfig } from "vite"
import react from "@vitejs/plugin-react"
import tailwindcss from "@tailwindcss/vite"
import { viteSingleFile } from "vite-plugin-singlefile"
import path from "node:path"

// SINGLE=1 → one self-contained HTML file. Otherwise a normal deployable folder.
const single = process.env.SINGLE === "1"
export default defineConfig({
  base: single ? "./" : "/",
  plugins: [react(), tailwindcss(), ...(single ? [viteSingleFile()] : [])],
  resolve: { alias: { "@": path.resolve(import.meta.dirname, "./src") } },
  build: {
    assetsInlineLimit: single ? 100_000_000 : 0,
    outDir: single ? "dist-single" : "dist",
  },
})
