import {
  cloneElement,
  isValidElement,
  useEffect,
  useId,
  useMemo,
  useRef,
  useState,
  type ReactElement,
  type RefObject,
} from "react"
import { AnimatePresence, MotionConfig, motion } from "motion/react"
import {
  ArrowRight,
  Check,
  ChevronRight,
  Coffee,
  MapPin,
  Menu as MenuIcon,
  MessageCircle,
  Minus,
  Phone,
  Plus,
  Search,
  ShoppingBag,
  Trash2,
  X,
} from "lucide-react"
import {
  categories,
  formatPrice,
  imageSrcSet,
  images,
  menu,
  type MenuItem,
} from "./data/menu"
import { faqs } from "./seo"
import masterCafeAbout from "./assets/master-cafe-about.webp"

const WHATSAPP = "https://wa.me/971554769522"
const DIRECTIONS =
  "https://www.google.com/maps/search/?api=1&query=GSeven+Hypermarket+Al+Ghurair+Building+Al+Muteena+Dubai"

type CartLine = {
  key: string
  item: MenuItem
  quantity: number
  variant?: string
  unitPrice: number
}

type OrderForm = {
  name: string
  phone: string
  orderType: "Delivery" | "Pickup"
  area: string
  address: string
  building: string
  landmark: string
  notes: string
}

const FOCUSABLE =
  'a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])'

/** Moves focus into a dialog, keeps Tab inside it and restores focus on close. */
function useDialog(open: boolean, ref: RefObject<HTMLElement | null>) {
  useEffect(() => {
    const node = ref.current
    if (!open || !node) return
    const previous = document.activeElement as HTMLElement | null
    node.querySelector<HTMLElement>(FOCUSABLE)?.focus()
    const onKey = (event: KeyboardEvent) => {
      if (event.key !== "Tab") return
      const items = [...node.querySelectorAll<HTMLElement>(FOCUSABLE)].filter(
        (el) => el.offsetParent !== null,
      )
      if (!items.length) return
      const first = items[0]
      const last = items[items.length - 1]
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault()
        last.focus()
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault()
        first.focus()
      }
    }
    node.addEventListener("keydown", onKey)
    return () => {
      node.removeEventListener("keydown", onKey)
      previous?.focus?.()
    }
  }, [open, ref])
}

const MAX_QTY = 99

/** Rebuild cart lines from the live menu; drop anything unknown, unavailable or malformed. */
function sanitizeLines(raw: unknown[]): CartLine[] {
  const lines: CartLine[] = []
  for (const entry of raw) {
    const e = entry as { item?: { id?: unknown }; variant?: unknown; quantity?: unknown }
    const item = menu.find((m) => m.id === e?.item?.id && m.available)
    const qty = Number(e?.quantity)
    if (!item || !Number.isInteger(qty) || qty < 1) continue
    const variant = item.priceVariants?.find((v) => v.label === e.variant)
    if (item.priceVariants && !variant) continue
    const key = `${item.id}-${variant?.label || "standard"}`
    if (lines.some((l) => l.key === key)) continue
    lines.push({
      key,
      item,
      quantity: Math.min(qty, MAX_QTY),
      variant: variant?.label,
      unitPrice: variant?.price ?? item.price,
    })
  }
  return lines
}

const photo = (src: string, sizes: string) => ({
  src,
  srcSet: imageSrcSet(src),
  sizes,
  decoding: "async" as const,
})

const Button = ({
  children,
  className = "",
  ...props
}: React.ButtonHTMLAttributes<HTMLButtonElement>) => (
  <button className={`button ${className}`} {...props}>
    {children}
  </button>
)

const LinkButton = ({
  children,
  className = "",
  ...props
}: React.AnchorHTMLAttributes<HTMLAnchorElement>) => (
  <a className={`button ${className}`} {...props}>
    {children}
  </a>
)

const SectionTitle = ({
  eyebrow,
  title,
  copy,
}: {
  eyebrow: string
  title: string
  copy?: string
}) => (
  <div className="section-title">
    <p className="eyebrow">{eyebrow}</p>
    <h2>{title}</h2>
    {copy && <p>{copy}</p>}
  </div>
)

function App() {
  const [navOpen, setNavOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const [category, setCategory] = useState("All")
  const [search, setSearch] = useState("")
  const [priceFilter, setPriceFilter] = useState("All prices")
  const [visible, setVisible] = useState(12)
  const [quickView, setQuickView] = useState<MenuItem | null>(null)
  const [selectedVariant, setSelectedVariant] = useState(0)
  const [cartOpen, setCartOpen] = useState(false)
  const [checkout, setCheckout] = useState(false)
  const [toast, setToast] = useState("")
  const [cart, setCart] = useState<CartLine[]>([])
  const [lastOrder, setLastOrder] = useState<CartLine[]>([])
  const [storageReady, setStorageReady] = useState(false)
  const toastTimer = useRef<number | undefined>(undefined)
  const cartRef = useRef<HTMLElement>(null)
  const quickRef = useRef<HTMLDivElement>(null)
  const [form, setForm] = useState<OrderForm>({
    name: "",
    phone: "",
    orderType: "Delivery",
    area: "Al Muteena",
    address: "",
    building: "",
    landmark: "",
    notes: "",
  })
  const [errors, setErrors] = useState<Record<string, string>>({})

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30)
    window.addEventListener("scroll", onScroll, { passive: true })
    return () => window.removeEventListener("scroll", onScroll)
  }, [])

  // Read saved data after mount so the pre-rendered HTML and first client render match.
  // Stored data is untrusted: every line is rebuilt from the current menu so stale or
  // tampered prices, names and unavailable items never reach the cart or the order message.
  useEffect(() => {
    const read = (key: string): CartLine[] => {
      try {
        const value = JSON.parse(localStorage.getItem(key) || "[]")
        return Array.isArray(value) ? sanitizeLines(value) : []
      } catch {
        return []
      }
    }
    setCart(read("master-cafe-cart"))
    setLastOrder(read("master-cafe-last-order"))
    setStorageReady(true)
  }, [])

  useEffect(() => {
    if (!storageReady) return
    try {
      localStorage.setItem("master-cafe-cart", JSON.stringify(cart))
    } catch {
      /* storage unavailable (private mode / quota): the cart still works in memory */
    }
  }, [cart, storageReady])

  useDialog(cartOpen, cartRef)
  useDialog(quickView !== null, quickRef)

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setQuickView(null)
        setCartOpen(false)
      }
    }
    document.addEventListener("keydown", onKey)
    document.body.style.overflow = quickView || cartOpen ? "hidden" : ""
    return () => {
      document.removeEventListener("keydown", onKey)
      document.body.style.overflow = ""
    }
  }, [quickView, cartOpen])

  const filtered = useMemo(() => {
    const term = search.trim().toLowerCase()
    return menu.filter((item) => {
      const categoryMatch = category === "All" || item.category === category
      const searchMatch =
        !term || `${item.name} ${item.category}`.toLowerCase().includes(term)
      const low = item.price
      const priceMatch =
        priceFilter === "All prices" ||
        (priceFilter === "Under AED 5" && low < 5) ||
        (priceFilter === "AED 5–10" && low >= 5 && low <= 10) ||
        (priceFilter === "AED 10–15" && low > 10 && low <= 15) ||
        (priceFilter === "AED 15+" && low > 15)
      return categoryMatch && searchMatch && priceMatch
    })
  }, [category, search, priceFilter])

  useEffect(() => setVisible(12), [category, search, priceFilter])

  const itemCount = cart.reduce((sum, line) => sum + line.quantity, 0)
  const subtotal = cart.reduce(
    (sum, line) => sum + line.unitPrice * line.quantity,
    0,
  )

  const notify = (message: string) => {
    setToast(message)
    window.clearTimeout(toastTimer.current)
    toastTimer.current = window.setTimeout(() => setToast(""), 2600)
  }

  const addItem = (item: MenuItem, variantIndex = 0) => {
    if (!item.available) return
    const variant = item.priceVariants?.[variantIndex]
    const key = `${item.id}-${variant?.label || "standard"}`
    setCart((current) => {
      const exists = current.find((line) => line.key === key)
      if (exists) {
        return current.map((line) =>
          line.key === key
            ? { ...line, quantity: Math.min(MAX_QTY, line.quantity + 1) }
            : line,
        )
      }
      return [
        ...current,
        {
          key,
          item,
          quantity: 1,
          variant: variant?.label,
          unitPrice: variant?.price ?? item.price,
        },
      ]
    })
    notify(`${item.name} added`)
  }

  const changeQuantity = (key: string, amount: number) => {
    setCart((current) =>
      current
        .map((line) =>
          line.key === key
            ? { ...line, quantity: Math.min(MAX_QTY, line.quantity + amount) }
            : line,
        )
        .filter((line) => line.quantity > 0),
    )
  }

  const reorderLast = () => {
    setCart((current) => {
      const next = [...current]
      for (const line of lastOrder) {
        const item = menu.find((m) => m.id === line.item.id && m.available)
        if (!item) continue
        const variant = item.priceVariants?.find((v) => v.label === line.variant)
        const key = `${item.id}-${variant?.label || "standard"}`
        const existing = next.findIndex((l) => l.key === key)
        if (existing >= 0)
          next[existing] = {
            ...next[existing],
            quantity: next[existing].quantity + line.quantity,
          }
        else
          next.push({
            key,
            item,
            quantity: line.quantity,
            variant: variant?.label,
            unitPrice: variant?.price ?? item.price,
          })
      }
      return next
    })
    setCartOpen(true)
  }

  const setField = <K extends keyof OrderForm>(key: K, value: OrderForm[K]) => {
    setForm((current) => ({ ...current, [key]: value }))
    setErrors((current) => {
      if (!current[key]) return current
      const next = { ...current }
      delete next[key]
      return next
    })
  }

  const selectCategory = (name: string) => {
    setCategory(name)
    document
      .querySelector("#menu")
      ?.scrollIntoView({ behavior: "smooth", block: "start" })
  }

  const validateAndOrder = () => {
    const next: Record<string, string> = {}
    if (!form.name.trim()) next.name = "Please enter your name."
    const digits = form.phone.replace(/\D/g, "")
    if (!form.phone.trim()) next.phone = "Please enter your mobile number."
    else if (digits.length < 8 || digits.length > 15)
      next.phone = "Enter a valid mobile number, for example 055 123 4567."
    if (form.orderType === "Delivery" && !form.address.trim())
      next.address = "Please enter your delivery address."
    setErrors(next)
    if (Object.keys(next).length) {
      window.requestAnimationFrame(() =>
        cartRef.current
          ?.querySelector<HTMLElement>('[aria-invalid="true"]')
          ?.focus(),
      )
      return
    }

    const items = cart
      .map(
        (line) =>
          `• ${line.item.name}${
            line.variant ? ` (${line.variant})` : ""
          } × ${line.quantity} — AED ${formatPrice(line.unitPrice * line.quantity)}`,
      )
      .join("\n")
    const delivery =
      form.orderType === "Delivery"
        ? `📍 DELIVERY
━━━━━━━━━━━━━━
Area: ${form.area}
Address: ${form.address}
Building/Apartment: ${form.building || "—"}
Landmark: ${form.landmark || "—"}`
        : "📍 PICKUP\n━━━━━━━━━━━━━━\nPickup from Master Cafe inside GSeven Hypermarket."
    const message = `Hello Master Cafe! 👋

I'd like to place an order.

🍴 ORDER
━━━━━━━━━━━━━━
${items}

Subtotal: AED ${formatPrice(subtotal)}
Delivery: ${
      form.orderType === "Delivery" && form.area === "Other"
        ? "To be confirmed by Master Cafe"
        : "FREE"
    }
TOTAL: AED ${formatPrice(subtotal)}

👤 CUSTOMER
━━━━━━━━━━━━━━
Name: ${form.name}
Phone: ${form.phone}

${delivery}

Order Type: ${form.orderType}

📝 Notes:
${form.notes || "—"}

Please confirm availability and delivery time.

Thank you!`
    try {
      localStorage.setItem("master-cafe-last-order", JSON.stringify(cart))
    } catch {
      /* storage unavailable: ordering must still work */
    }
    setLastOrder(cart)
    const url = `${WHATSAPP}?text=${encodeURIComponent(message)}`
    // noopener makes window.open return null even on success, so it cannot detect a
    // blocked popup. Open a named blank window instead and fall back to same-tab navigation.
    const win = window.open(url, "_blank")
    if (win) win.opener = null
    else window.location.assign(url)
    notify("Opening WhatsApp. Send the message to confirm your order.")
  }

  return (
    <MotionConfig reducedMotion="user">
    <div className="app-shell">
      <a className="skip-link" href="#main">
        Skip to main content
      </a>

      <header className={`navbar ${scrolled ? "navbar--scrolled" : ""}`}>
        <a className="brand" href="#home" aria-label="Master Cafe home">
          <Coffee size={20} />
          <span>
            MASTER <b>CAFE</b>
          </span>
        </a>
        <nav
          id="primary-nav"
          className={navOpen ? "nav-links nav-links--open" : "nav-links"}
          aria-label="Main navigation"
        >
          <a href="#menu" onClick={() => setNavOpen(false)}>
            Menu
          </a>
          <a href="#about" onClick={() => setNavOpen(false)}>
            About
          </a>
          <a href="#delivery" onClick={() => setNavOpen(false)}>
            Delivery
          </a>
          <a href="#location" onClick={() => setNavOpen(false)}>
            Location
          </a>
        </nav>
        <div className="nav-actions">
          <Button
            className="icon-button cart-trigger"
            onClick={() => setCartOpen(true)}
            aria-label={`Open cart, ${itemCount} ${itemCount === 1 ? "item" : "items"}`}
          >
            <ShoppingBag size={20} />
            {itemCount > 0 && <span>{itemCount}</span>}
          </Button>
          <LinkButton
            className="primary nav-whatsapp"
            href={`${WHATSAPP}?text=${encodeURIComponent("Hello Master Cafe! I'd like to know today's menu and place an order.")}`}
            target="_blank" rel="noopener noreferrer"
          >
            Order on WhatsApp <ArrowRight size={16} />
          </LinkButton>
          <Button
            className="icon-button menu-trigger"
            onClick={() => setNavOpen(!navOpen)}
            aria-label="Menu"
            aria-expanded={navOpen}
            aria-controls="primary-nav"
          >
            {navOpen ? <X /> : <MenuIcon />}
          </Button>
        </div>
      </header>

      <main id="main">
        <section id="home" className="hero">
          <motion.div
            className="hero-bg"
            initial={{ scale: 1.08 }}
            animate={{ scale: 1 }}
            transition={{ duration: 2, ease: "easeOut" }}
          />
          <div className="hero-overlay" />
          <motion.div
            className="hero-content"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <p className="eyebrow hero-eyebrow">
              <MapPin size={14} /> Al Muteena · Deira · Dubai
            </p>
            <div className="accent-line" />
            <h1>
              Big Flavours.
              <br />
              <em>Small Prices.</em>
            </h1>
            <p className="hero-copy">
              Affordable burgers, shawarmas, Kerala favourites and refreshing
              drinks—freshly prepared, right around the corner.
            </p>
            <div className="hero-actions">
              <LinkButton className="primary" href="#menu">
                Explore Menu <ArrowRight size={18} />
              </LinkButton>
              <LinkButton
                className="secondary"
                href={`${WHATSAPP}?text=${encodeURIComponent("Hello Master Cafe! I'd like to know today's menu and place an order.")}`}
                target="_blank"
                rel="noopener noreferrer"
              >
                Order on WhatsApp <MessageCircle size={18} />
              </LinkButton>
              <LinkButton
                className="secondary"
                href={DIRECTIONS}
                target="_blank" rel="noopener noreferrer"
              >
                Get Directions <MapPin size={18} />
              </LinkButton>
            </div>
          </motion.div>
          <div className="hero-note">
            Inside GSeven
            <br />
            Hypermarket
          </div>
        </section>

        <section className="trust-strip" aria-label="Master Cafe benefits">
          {[
            "AED 1 Snacks",
            "Free Local Delivery",
            "WhatsApp Ordering",
            "Inside GSeven Hypermarket",
          ].map((text) => (
            <div key={text}>
              <Check size={16} /> {text}
            </div>
          ))}
        </section>

        <section className="one-dirham section">
          <div className="one-dirham-copy">
            <p className="eyebrow">Everyday value</p>
            <h2>
              AED <em>1</em>
              <br />
              Favourites
            </h2>
            <p>
              Your cravings don&apos;t need a big budget. Tea and crisp savoury
              favourites from just one dirham.
            </p>
            <Button
              className="text-button"
              onClick={() => {
                setPriceFilter("Under AED 5")
                selectCategory("All")
              }}
            >
              Explore AED 1 favourites <ArrowRight size={18} />
            </Button>
          </div>
          <div className="one-dirham-list">
            {[
              "Kadak Tea",
              "Black Tea",
              "Green Tea",
              "Chi / Veg Samosa",
              "Aloo Samosa",
            ].map((name, index) => (
              <div key={name}>
                <span>0{index + 1}</span>
                <strong>{name}</strong>
                <b>AED 1</b>
              </div>
            ))}
          </div>
        </section>

        <div className="category-wrap">
          <div className="category-nav" role="group" aria-label="Menu categories">
            {categories.map((name) => (
              <button
                key={name}
                className={category === name ? "active" : ""}
                aria-pressed={category === name}
                onClick={() => selectCategory(name)}
              >
                {name}
              </button>
            ))}
          </div>
        </div>

        <section className="cravings section">
          <SectionTitle
            eyebrow="Curated for every craving"
            title="What are you craving?"
            copy="From slow mornings to after-shopping shawarmas, there is always something worth stopping for."
          />
          <div className="craving-grid">
            {[
              [
                "Morning Favourites",
                "Idli · Dosa · Puttu · Chapathi",
                images.breakfast,
                "Breakfast",
              ],
              [
                "Street Food",
                "Samosa · Chaat · Vada Pav · Fries",
                images.idli,
                "Snacks",
              ],
              [
                "Burgers & Wraps",
                "Zinger · Tikka · Chicken Fillet",
                images.burger,
                "Burgers",
              ],
              [
                "Refreshments",
                "Juices · Lassi · Mojitos · Shakes",
                images.drink,
                "Fresh Juices",
              ],
            ].map(([title, copy, image, target]) => (
              <button
                className="craving-card"
                key={title}
                onClick={() => selectCategory(target)}
              >
                <img
                  {...photo(image, "(max-width:700px) 90vw, 25vw")}
                  width={600}
                  height={460}
                  alt=""
                  loading="lazy"
                />
                <span>
                  <small>Explore</small>
                  <strong>{title}</strong>
                  <em>{copy}</em>
                  <ChevronRight />
                </span>
              </button>
            ))}
          </div>
        </section>

        {lastOrder.length > 0 && (
          <section className="usual section">
            <div>
              <p className="eyebrow">Saved on this device</p>
              <h2>Order your usual?</h2>
              <p>
                {lastOrder
                  .slice(0, 3)
                  .map(
                    (line) =>
                      `${line.item.name}${line.variant ? ` (${line.variant})` : ""} × ${line.quantity}`,
                  )
                  .join(" · ")}
              </p>
            </div>
            <Button
              className="primary"
              onClick={reorderLast}
            >
              Add again <Plus size={17} />
            </Button>
          </section>
        )}

        <section id="menu" className="menu-section section">
          <SectionTitle
            eyebrow={`${menu.length} favourites · freshly prepared`}
            title="The complete menu."
            copy="Search, filter and build your order in a few taps."
          />
          <div className="menu-tools">
            <label className="search-box">
              <Search size={19} />
              <input
                type="search"
                name="menu-search"
                aria-label="Search the menu"
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                placeholder="Search burgers, shawarma, juices..."
              />
            </label>
            <label className="select-box">
              <span>Price</span>
              <select
                name="price-filter"
                value={priceFilter}
                onChange={(event) => setPriceFilter(event.target.value)}
              >
                {[
                  "All prices",
                  "Under AED 5",
                  "AED 5–10",
                  "AED 10–15",
                  "AED 15+",
                ].map((value) => (
                  <option key={value}>{value}</option>
                ))}
              </select>
            </label>
          </div>
          <div className="menu-result-head">
            <p role="status">
              <strong>{category}</strong> <span>{filtered.length} items</span>
            </p>
            {(search || priceFilter !== "All prices" || category !== "All") && (
              <Button
                className="clear-filter"
                onClick={() => {
                  setSearch("")
                  setPriceFilter("All prices")
                  setCategory("All")
                }}
              >
                Clear filters
              </Button>
            )}
          </div>
          {filtered.length ? (
            <>
              <motion.div layout className="menu-grid">
                <AnimatePresence mode="popLayout">
                  {filtered.slice(0, visible).map((item) => (
                    <motion.article
                      layout
                      initial={{ opacity: 0, y: 16 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                      className="menu-card"
                      key={item.id}
                    >
                      <div className="card-content">
                        <h3>{item.name}</h3>
                        <div className="card-footer">
                          <p>
                            <small>{item.priceVariants ? "From " : ""}</small>
                            AED {formatPrice(item.price)}
                          </p>
                          <Button
                            aria-label={`${item.priceVariants ? "Choose size for" : "Add"} ${item.name}`}
                            onClick={() =>
                              item.priceVariants
                                ? (setQuickView(item), setSelectedVariant(0))
                                : addItem(item)
                            }
                          >
                            {item.priceVariants ? "Choose" : "Add"}{" "}
                            <Plus size={16} />
                          </Button>
                        </div>
                      </div>
                    </motion.article>
                  ))}
                </AnimatePresence>
              </motion.div>
              {visible < filtered.length && (
                <Button
                  className="load-more"
                  onClick={() => setVisible((count) => count + 12)}
                >
                  Show more favourites <ArrowRight size={17} />
                </Button>
              )}
            </>
          ) : (
            <div className="empty-state">
              <Search />
              <h3>No dishes found</h3>
              <p>Try another search or clear the filters.</p>
            </div>
          )}
        </section>

        <section className="under-ten section">
          <div className="under-ten-heading">
            <p className="eyebrow">Everyday value</p>
            <h2>
              Great Food.
              <br />
              <em>Under AED 10.</em>
            </h2>
          </div>
          <div className="under-ten-list">
            {menu
              .filter((item) => item.price < 10)
              .slice(0, 8)
              .map((item, index) => (
                <button key={item.id} onClick={() => addItem(item)}>
                  <span>0{index + 1}</span>
                  <strong>{item.name}</strong>
                  <b>AED {formatPrice(item.price)}</b>
                  <Plus />
                </button>
              ))}
          </div>
        </section>

        <section id="delivery" className="delivery section">
          <img
            {...photo(images.wrap, "100vw")}
            alt="Freshly prepared wrap ready to order"
            loading="lazy"
          />
          <div className="delivery-overlay" />
          <div className="delivery-copy">
            <p className="eyebrow">Free local delivery · Al Muteena / Deira</p>
            <h2>
              Too busy to come out?
              <br />
              <em>We&apos;ll bring it to you.</em>
            </h2>
            <p>
              Enjoy your Master Cafe favourites from the comfort of home. Call
              or WhatsApp to order.
            </p>
            <div>
              <LinkButton className="primary" href={WHATSAPP} target="_blank" rel="noopener noreferrer">
                Order on WhatsApp <ArrowRight size={18} />
              </LinkButton>
              <LinkButton className="secondary" href="tel:+971554769522">
                <Phone size={17} /> 055 476 9522
              </LinkButton>
            </div>
          </div>
        </section>

        <section id="about" className="about section">
          <div className="about-image">
            <img
              src={masterCafeAbout}
              width={256}
              height={165}
              decoding="async"
              alt="Master Cafe storefront inside GSeven Hypermarket"
              loading="lazy"
            />
            <span>
              Right around
              <br />
              the corner.
            </span>
          </div>
          <div className="about-copy">
            <SectionTitle
              eyebrow="About Master Cafe"
              title="Your local stop for big flavours."
            />
            <p>
              Located inside GSeven Hypermarket in Al Muteena, Master Cafe
              brings together affordable South Asian comfort food, quick bites,
              refreshing drinks and satisfying meals under one roof.
            </p>
            <p>
              Whether you&apos;re grabbing a morning breakfast, a quick AED 1
              snack, a filling burger, a shawarma after shopping or a fresh
              juice on the way home, Master Cafe is built for everyday cravings.
            </p>
            <div className="about-facts">
              <span>
                <b>AED 1</b>Starting snacks
              </span>
              <span>
                <b>100+</b>Menu favourites
              </span>
              <span>
                <b>FREE</b>Local delivery
              </span>
            </div>
          </div>
        </section>

        <section className="gallery section">
          <SectionTitle eyebrow="From our menu" title="Made for the moment." />
          <div className="gallery-track">
            {[
              images.burger,
              images.wrap,
              images.breakfast,
              images.drink,
              images.idli,
            ].map((src, index) => (
              <figure key={src}>
                <img
                  {...photo(src, "(max-width:700px) 80vw, 33vw")}
                  alt={
                    [
                      "Burger close-up",
                      "Fresh wrap",
                      "South Indian breakfast",
                      "Cafe refreshment",
                      "Idli breakfast",
                    ][index]
                  }
                  loading="lazy"
                />
                <figcaption>
                  {
                    [
                      "Loaded favourites",
                      "Wrapped fresh",
                      "Morning classics",
                      "Fresh pours",
                      "Comfort food",
                    ][index]
                  }
                </figcaption>
              </figure>
            ))}
          </div>
        </section>

        <section id="location" className="location section">
          <div className="location-card">
            <p className="eyebrow">Find Master Cafe</p>
            <h2>
              Inside GSeven
              <br />
              Hypermarket.
            </h2>
            <address>
              Al Ghurair Building
              <br />
              Al Muteena, Deira
              <br />
              Dubai, UAE
            </address>
            <div className="location-actions">
              <LinkButton className="primary" href={DIRECTIONS} target="_blank" rel="noopener noreferrer">
                <MapPin size={17} /> Get Directions
              </LinkButton>
              <LinkButton className="secondary" href="tel:+971554769522">
                <Phone size={17} /> Call Now
              </LinkButton>
            </div>
          </div>
          <div className="map-panel">
            <MapPin />
            <span>AL MUTEENA</span>
            <strong>
              MASTER
              <br />
              CAFE
            </strong>
            <p>
              Master Cafe is located inside GSeven Hypermarket LLC at Al Ghurair
              Building in Al Muteena, Deira, Dubai.
            </p>
          </div>
        </section>

        <section id="faq" className="faq section">
          <SectionTitle
            eyebrow="Good to know"
            title="Frequently asked questions"
          />
          <div className="faq-list">
            {faqs.map((item) => (
              <details key={item.q}>
                <summary>{item.q}</summary>
                <p>{item.a}</p>
              </details>
            ))}
          </div>
        </section>

        <section className="local-seo section">
          <p className="eyebrow">Food in Deira, made easy</p>
          <h2>Master Cafe in Al Muteena, Deira</h2>
          <p>
            Looking for an affordable cafe near GSeven Hypermarket? Master Cafe
            serves Kerala-style and South Indian breakfast, burgers, shawarma,
            wraps, snacks, fresh juices, tea, coffee, lassi, mojitos, shakes and
            desserts. Visit us inside GSeven Hypermarket, call ahead, or order
            directly on WhatsApp with free local delivery in Al Muteena and
            Deira.
          </p>
        </section>

        <section className="final-cta section">
          <p className="eyebrow">Fresh flavours · Small prices</p>
          <h2>
            Your next favourite
            <br />
            is one message away.
          </h2>
          <LinkButton className="primary" href={WHATSAPP} target="_blank" rel="noopener noreferrer">
            Start a WhatsApp order <ArrowRight />
          </LinkButton>
        </section>
      </main>

      <footer>
        <div className="footer-brand">
          <a className="brand" href="#home">
            <Coffee />{" "}
            <span>
              MASTER <b>CAFE</b>
            </span>
          </a>
          <h3>
            Big Flavours.
            <br />
            <em>Small Prices.</em>
          </h3>
        </div>
        <div>
          <p className="footer-label">Visit</p>
          <address>
            Inside GSeven Hypermarket LLC
            <br />
            Al Ghurair Building
            <br />
            Al Muteena, Deira
            <br />
            Dubai, UAE
          </address>
        </div>
        <div>
          <p className="footer-label">Explore</p>
          <a href="#menu">Menu</a>
          <a href="#delivery">Delivery</a>
          <a href="#location">Location</a>
          <a href="#faq">FAQ</a>
        </div>
        <div>
          <p className="footer-label">Order</p>
          <a href={WHATSAPP} target="_blank" rel="noopener noreferrer">WhatsApp</a>
          <a href="tel:+971554769522">055 476 9522</a>
          <a href={DIRECTIONS} target="_blank" rel="noopener noreferrer">Get Directions</a>
        </div>
        <p className="footer-seo">
          Master Cafe is a local café in Al Muteena, Deira, Dubai, offering
          affordable burgers, shawarma, wraps, Kerala-style breakfast, snacks,
          fresh juices, tea, coffee, lassi, mojitos, shakes and desserts, with
          local delivery available.
        </p>
        <div className="footer-bottom">
          <span>© 2026 Master Cafe. All rights reserved.</span>
          <span>Big flavours, right around the corner.</span>
        </div>
      </footer>

      <AnimatePresence>
        {quickView && (
          <motion.div
            className="modal-backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onMouseDown={() => setQuickView(null)}
          >
            <motion.div
              ref={quickRef}
              className="quick-view"
              role="dialog"
              aria-modal="true"
              aria-labelledby="quick-title"
              initial={{ opacity: 0, scale: 0.96, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.96 }}
              onMouseDown={(event) => event.stopPropagation()}
            >
              <Button
                className="modal-close icon-button"
                onClick={() => setQuickView(null)}
                aria-label="Close item"
              >
                <X />
              </Button>
              <div className="quick-copy">
                <p className="eyebrow">{quickView.category}</p>
                <h2 id="quick-title">{quickView.name}</h2>
                <p>
                  {quickView.category === "Combos"
                    ? "Combo meal. Ask on WhatsApp what is included today."
                    : "Freshly prepared by Master Cafe."}
                </p>
                {quickView.priceVariants && (
                  <fieldset>
                    <legend>Choose size</legend>
                    <div className="variant-options">
                      {quickView.priceVariants.map((variant, index) => (
                        <button
                          className={selectedVariant === index ? "active" : ""}
                          aria-pressed={selectedVariant === index}
                          key={variant.label}
                          onClick={() => setSelectedVariant(index)}
                        >
                          <span>{variant.label}</span>
                          <b>AED {formatPrice(variant.price)}</b>
                        </button>
                      ))}
                    </div>
                  </fieldset>
                )}
                <div className="quick-footer">
                  <p>
                    AED{" "}
                    {formatPrice(
                      quickView.priceVariants?.[selectedVariant]?.price ??
                        quickView.price,
                    )}
                  </p>
                  <Button
                    className="primary"
                    onClick={() => {
                      addItem(quickView, selectedVariant)
                      setQuickView(null)
                    }}
                  >
                    Add to Cart <Plus size={18} />
                  </Button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {cartOpen && (
          <motion.div
            className="drawer-backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onMouseDown={() => setCartOpen(false)}
          >
            <motion.aside
              ref={cartRef}
              className="cart-drawer"
              role="dialog"
              aria-modal="true"
              aria-labelledby="cart-title"
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 28, stiffness: 260 }}
              onMouseDown={(event) => event.stopPropagation()}
            >
              <div className="drawer-head">
                <div>
                  <p className="eyebrow">
                    {checkout
                      ? "Final step"
                      : `${itemCount} ${itemCount === 1 ? "item" : "items"}`}
                  </p>
                  <h2 id="cart-title">
                    {checkout ? "Your details" : "Your order"}
                  </h2>
                </div>
                <Button
                  className="icon-button"
                  onClick={() => setCartOpen(false)}
                  aria-label="Close cart"
                >
                  <X />
                </Button>
              </div>
              {!cart.length ? (
                <div className="cart-empty">
                  <ShoppingBag />
                  <h3>Your cart is empty</h3>
                  <p>
                    Add a few favourites and come back when you&apos;re ready.
                  </p>
                  <Button
                    className="primary"
                    onClick={() => {
                      setCartOpen(false)
                      selectCategory("All")
                    }}
                  >
                    Explore menu
                  </Button>
                </div>
              ) : checkout ? (
                <div className="checkout-form">
                  <div className="order-mini">
                    {cart.map((line) => (
                      <p key={line.key}>
                        <span>
                          {line.item.name} × {line.quantity}
                        </span>
                        <b>AED {formatPrice(line.unitPrice * line.quantity)}</b>
                      </p>
                    ))}
                  </div>
                  <div className="type-toggle" role="group" aria-label="Order type">
                    {(["Delivery", "Pickup"] as const).map((type) => (
                      <button
                        key={type}
                        className={form.orderType === type ? "active" : ""}
                        aria-pressed={form.orderType === type}
                        onClick={() => setField("orderType", type)}
                      >
                        {type}
                      </button>
                    ))}
                  </div>
                  <FormField label="Customer name" error={errors.name} required>
                    <input
                      value={form.name}
                      onChange={(e) => setField("name", e.target.value)}
 name="name" maxLength={80}
                      autoComplete="name"
                    />
                  </FormField>
                  <FormField label="Mobile number" error={errors.phone} required>
                    <input
                      value={form.phone}
                      onChange={(e) => setField("phone", e.target.value)}
 name="phone" maxLength={20} type="tel"
                      inputMode="tel"
                      autoComplete="tel"
                    />
                  </FormField>
                  {form.orderType === "Delivery" && (
                    <>
                      <FormField label="Delivery area">
                        <select
                          value={form.area}
                          onChange={(e) => setField("area", e.target.value)}
 name="area"
                        >
                          <option>Al Muteena</option>
                          <option>Deira</option>
                          <option>Other</option>
                        </select>
                      </FormField>
                      <FormField
                        label="Full delivery address"
                        error={errors.address}
                        required
                      >
                        <textarea
                          value={form.address}
                          onChange={(e) => setField("address", e.target.value)}
 name="address" maxLength={250} autoComplete="street-address"
                        />
                      </FormField>
                      <FormField label="Building / Apartment · Optional">
                        <input
                          value={form.building}
                          onChange={(e) => setField("building", e.target.value)}
 name="building" maxLength={80} autoComplete="address-line2"
                        />
                      </FormField>
                      <FormField label="Landmark · Recommended">
                        <input
                          value={form.landmark}
                          onChange={(e) => setField("landmark", e.target.value)}
 name="landmark" maxLength={80}
                        />
                      </FormField>
                    </>
                  )}
                  <FormField label="Additional instructions · Optional">
                    <textarea
                      value={form.notes}
                      onChange={(e) => setField("notes", e.target.value)}
 name="notes" maxLength={300}
                      placeholder="Please call when you arrive."
                    />
                  </FormField>
                  <p className="checkout-note">
                    This prepares your order and opens WhatsApp. Master Cafe
                    will confirm availability and timing.
                  </p>
                </div>
              ) : (
                <div className="cart-lines">
                  {cart.map((line) => (
                    <div className="cart-line" key={line.key}>
                      <div>
                        <h3>{line.item.name}</h3>
                        {line.variant && <p>{line.variant}</p>}
                        <b>AED {formatPrice(line.unitPrice)}</b>
                      </div>
                      <div className="quantity">
                        <button
                          onClick={() => changeQuantity(line.key, -1)}
                          aria-label={`Decrease ${line.item.name}`}
                        >
                          <Minus />
                        </button>
                        <span>{line.quantity}</span>
                        <button
                          onClick={() => changeQuantity(line.key, 1)}
                          aria-label={`Increase ${line.item.name}`}
                        >
                          <Plus />
                        </button>
                      </div>
                    </div>
                  ))}
                  <Button className="clear-cart" onClick={() => setCart([])}>
                    <Trash2 size={15} /> Clear cart
                  </Button>
                </div>
              )}
              {cart.length > 0 && (
                <div className="cart-total">
                  <p>
                    <span>Subtotal</span>
                    <b>AED {formatPrice(subtotal)}</b>
                  </p>
                  <p>
                    <span>Local delivery</span>
                    <b className="free">FREE</b>
                  </p>
                  <div>
                    <span>Total</span>
                    <strong>AED {formatPrice(subtotal)}</strong>
                  </div>
                  {checkout ? (
                    <>
                      <Button
                        className="primary checkout-button"
                        onClick={validateAndOrder}
                      >
                        Continue to WhatsApp <ArrowRight />
                      </Button>
                      <Button
                        className="back-button"
                        onClick={() => setCheckout(false)}
                      >
                        Back to cart
                      </Button>
                    </>
                  ) : (
                    <Button
                      className="primary checkout-button"
                      onClick={() => setCheckout(true)}
                    >
                      Review order <ArrowRight />
                    </Button>
                  )}
                </div>
              )}
            </motion.aside>
          </motion.div>
        )}
      </AnimatePresence>

      <div role="status" aria-live="polite">
      <AnimatePresence>
        {toast && (
          <motion.div
            className="toast"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
          >
            <Check /> {toast}
          </motion.div>
        )}
      </AnimatePresence>
      </div>

      <LinkButton
        className="floating-whatsapp"
        href={`${WHATSAPP}?text=${encodeURIComponent("Hello Master Cafe! I'd like to know today's menu and place an order.")}`}
        target="_blank" rel="noopener noreferrer"
      >
        <span>WA</span> WhatsApp Us
      </LinkButton>

      <nav className="mobile-bottom" aria-label="Mobile navigation">
        <a href="#home">
          <Coffee />
          <span>Home</span>
        </a>
        <a href="#menu">
          <Search />
          <span>Menu</span>
        </a>
        <button onClick={() => setCartOpen(true)}>
          <span className="mobile-cart-icon">
            <ShoppingBag />
            {itemCount > 0 && <b>{itemCount}</b>}
          </span>
          <span>Cart</span>
        </button>
        <a href={WHATSAPP} target="_blank" rel="noopener noreferrer">
          <ArrowRight />
          <span>WhatsApp</span>
        </a>
        <a href="#location">
          <MapPin />
          <span>Location</span>
        </a>
      </nav>
    </div>
    </MotionConfig>
  )
}

function FormField({
  label,
  error,
  required,
  children,
}: {
  label: string
  error?: string
  required?: boolean
  children: React.ReactNode
}) {
  const id = useId()
  const control = isValidElement(children)
    ? cloneElement(children as ReactElement<Record<string, unknown>>, {
        id,
        "aria-invalid": error ? true : undefined,
        "aria-describedby": error ? `${id}-error` : undefined,
        required: required || undefined,
      })
    : children
  return (
    <div className={`form-field ${error ? "has-error" : ""}`}>
      <label htmlFor={id}>{label}</label>
      {control}
      {error && (
        <p id={`${id}-error`} className="field-error" role="alert">
          {error}
        </p>
      )}
    </div>
  )
}

export default App
