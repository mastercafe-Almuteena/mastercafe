import { categories, formatPrice, menu } from "./data/menu"

export const BUSINESS = {
  name: "Master Cafe",
  phone: "+971554769522",
  phoneDisplay: "055 476 9522",
  street: "Inside GSeven Hypermarket LLC, Al Ghurair Building",
  locality: "Al Muteena, Deira",
  region: "Dubai",
  country: "AE",
}

export const SEO = {
  title: "Master Cafe | Burgers, Shawarma & Breakfast in Al Muteena, Deira",
  description:
    "Affordable burgers, shawarma, Kerala-style breakfast, snacks and fresh juices inside GSeven Hypermarket, Al Muteena, Deira. Free local delivery. Order on WhatsApp.",
  ogTitle: "Master Cafe · Big Flavours. Small Prices.",
  ogDescription:
    "Affordable burgers, shawarma, Kerala favourites and fresh drinks in Al Muteena, Deira. Free local delivery.",
  ogImage:
    "https://images.unsplash.com/photo-1607730127050-e32a8c756fb9?auto=format&fit=crop&w=1200&q=82",
}

const menuCategories = categories.slice(1)
const aed1 = menu.filter((item) => item.price === 1).map((item) => item.name)
const prices = menu.map((item) => item.price)
const maxPrice = Math.max(...prices)

/** Visible FAQ content. Every answer is derived from facts already on the site. */
export const faqs: Array<{ q: string; a: string }> = [
  {
    q: "Where is Master Cafe located?",
    a: `Master Cafe is inside GSeven Hypermarket LLC, Al Ghurair Building, Al Muteena, Deira, Dubai, UAE.`,
  },
  {
    q: "Does Master Cafe deliver?",
    a: `Yes. Master Cafe offers free local delivery in Al Muteena and Deira. Order through this website, which prepares your order and opens WhatsApp, or call ${BUSINESS.phoneDisplay}. The cafe confirms availability and timing when you order.`,
  },
  {
    q: "How do I order from Master Cafe?",
    a: `Add dishes to your cart, choose Delivery or Pickup, enter your details and continue to WhatsApp. Your order message is prepared for you and Master Cafe confirms it. You can also call ${BUSINESS.phoneDisplay}.`,
  },
  {
    q: "Can I pick up my order?",
    a: "Yes. Choose Pickup at checkout and collect from Master Cafe inside GSeven Hypermarket in Al Muteena.",
  },
  {
    q: "What food and drinks does Master Cafe serve?",
    a: `The menu has ${menu.length} items in ${menuCategories.length} categories: ${menuCategories.join(", ")}. Prices start at AED 1.`,
  },
  {
    q: "What is the cheapest item on the menu?",
    a: `${aed1.join(", ")} are each AED 1. Breakfast items start from AED ${Math.min(...menu.filter((i) => i.category === "Breakfast").map((i) => i.price))}.`,
  },
]

export function buildJsonLd(siteUrl?: string) {
  const id = siteUrl ? `${siteUrl}/#restaurant` : undefined
  const restaurant = {
    "@type": "Restaurant",
    ...(id && { "@id": id, url: `${siteUrl}/` }),
    name: BUSINESS.name,
    telephone: BUSINESS.phone,
    description:
      "Affordable South Asian and Kerala-inspired breakfast, burgers, shawarma, snacks, fresh juices and cafe drinks in Al Muteena, Deira.",
    servesCuisine: ["South Asian", "Kerala", "Indian", "Fast Food", "Street Food"],
    priceRange: `AED 1–AED ${maxPrice}`,
    currenciesAccepted: "AED",
    address: {
      "@type": "PostalAddress",
      streetAddress: BUSINESS.street,
      addressLocality: BUSINESS.locality,
      addressRegion: BUSINESS.region,
      addressCountry: BUSINESS.country,
    },
    areaServed: ["Al Muteena", "Deira"],
    hasMap:
      "https://www.google.com/maps/search/?api=1&query=GSeven+Hypermarket+Al+Ghurair+Building+Al+Muteena+Dubai",
    potentialAction: {
      "@type": "OrderAction",
      target: {
        "@type": "EntryPoint",
        urlTemplate: "https://wa.me/971554769522",
        actionPlatform: [
          "http://schema.org/DesktopWebPlatform",
          "http://schema.org/MobileWebPlatform",
        ],
      },
      deliveryMethod: [
        "http://purl.org/goodrelations/v1#DeliveryModeOwnFleet",
        "http://purl.org/goodrelations/v1#DeliveryModePickUp",
      ],
    },
    hasMenu: {
      "@type": "Menu",
      name: "Master Cafe Menu",
      hasMenuSection: menuCategories.map((name) => ({
        "@type": "MenuSection",
        name,
        hasMenuItem: menu
          .filter((item) => item.category === name)
          .map((item) => ({
            "@type": "MenuItem",
            name: item.name,
            offers: item.priceVariants
              ? item.priceVariants.map((v) => ({
                  "@type": "Offer",
                  name: v.label,
                  price: formatPrice(v.price),
                  priceCurrency: "AED",
                }))
              : {
                  "@type": "Offer",
                  price: formatPrice(item.price),
                  priceCurrency: "AED",
                },
          })),
      })),
    },
  }
  return {
    "@context": "https://schema.org",
    "@graph": [
      restaurant,
      ...(siteUrl
        ? [
            {
              "@type": "WebSite",
              "@id": `${siteUrl}/#website`,
              url: `${siteUrl}/`,
              name: BUSINESS.name,
              inLanguage: "en",
              publisher: { "@id": id },
            },
          ]
        : []),
      {
        "@type": "FAQPage",
        mainEntity: faqs.map((f) => ({
          "@type": "Question",
          name: f.q,
          acceptedAnswer: { "@type": "Answer", text: f.a },
        })),
      },
    ],
  }
}
