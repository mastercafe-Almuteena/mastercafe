import React from "react"
import { createRoot, hydrateRoot } from "react-dom/client"
import App from "./App"
import "./index.css"

const root = document.getElementById("root")!
const app = (
  <React.StrictMode>
    <App />
  </React.StrictMode>
)
// The build pre-renders the page into #root for crawlers; hydrate it when present.
if (root.hasChildNodes()) hydrateRoot(root, app)
else createRoot(root).render(app)
