import { renderToString } from "react-dom/server"
import App from "./App"

export const render = () => renderToString(<App />)
export { menu, categories, formatPrice } from "./data/menu"
export { SEO, BUSINESS, faqs, buildJsonLd } from "./seo"
