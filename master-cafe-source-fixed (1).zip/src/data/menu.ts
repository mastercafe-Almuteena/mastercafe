export type PriceVariant = { label: string; price: number }

export type MenuItem = {
  id: string
  name: string
  category: string
  price: number
  priceVariants?: PriceVariant[]
  description?: string
  image: string
  featured?: boolean
  available: boolean
  vegetarian?: boolean
  popular?: boolean
  badge?: "BEST VALUE" | "POPULAR" | "AED 1" | "NEW" | "COMBO"
}

export const images = {
  burger:
    "https://images.unsplash.com/photo-1551782450-a2132b4ba21d?auto=format&fit=crop&w=1200&q=82",
  club: "https://images.unsplash.com/photo-1655195672061-90c23e3e8026?auto=format&fit=crop&w=1200&q=82",
  wrap: "https://images.unsplash.com/photo-1719282431565-3b30bb7d2658?auto=format&fit=crop&w=1200&q=82",
  shawarma:
    "https://images.unsplash.com/photo-1760888548893-bc2f7e09e972?auto=format&fit=crop&w=1200&q=82",
  parota:
    "https://images.unsplash.com/photo-1629450748686-c86699b710ac?auto=format&fit=crop&w=1200&q=82",
  breakfast:
    "https://images.unsplash.com/photo-1789993494828-735441249a30?auto=format&fit=crop&w=1200&q=82",
  idli: "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&w=1200&q=82",
  samosa:
    "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=1200&q=82",
  chaat:
    "https://images.unsplash.com/photo-1697155836252-d7f969108b5a?auto=format&fit=crop&w=1200&q=82",
  fries:
    "https://images.unsplash.com/photo-1615653633266-1ee0c84500b2?auto=format&fit=crop&w=1200&q=82",
  juice:
    "https://images.unsplash.com/photo-1603569283847-aa295f0d016a?auto=format&fit=crop&w=1200&q=82",
  mojito:
    "https://images.unsplash.com/photo-1676159434937-c7b51a52ff5a?auto=format&fit=crop&w=1200&q=82",
  lassi:
    "https://images.unsplash.com/photo-1623065422902-30a2d299bbe4?auto=format&fit=crop&w=1200&q=82",
  shake:
    "https://images.unsplash.com/photo-1653542773369-51cce8d08250?auto=format&fit=crop&w=1200&q=82",
  coffee:
    "https://images.unsplash.com/photo-1730871083403-6067c6ab2cfb?auto=format&fit=crop&w=1200&q=82",
  dessert:
    "https://images.unsplash.com/photo-1774873394237-aef55aa0fc5c?auto=format&fit=crop&w=1200&q=82",
  drink:
    "https://images.unsplash.com/photo-1583577612013-4fecf7bf8f13?auto=format&fit=crop&w=1200&q=82",
  cafe: "https://images.unsplash.com/photo-1701722952679-beffce26d77a?auto=format&fit=crop&w=1400&q=82",
}

const imageFor = (category: string, name: string) => {
  const item = name.toLowerCase()

  if (item.includes("idli")) return images.idli
  if (category === "Breakfast") return images.breakfast
  if (category === "Club Sandwich") return images.club
  if (["Burgers", "Special Burgers", "Combos"].includes(category))
    return images.burger
  if (category === "Shawarma") return images.shawarma
  if (category === "Parota") return images.parota
  if (category === "Wraps") return images.wrap
  if (category === "Chaat") return images.chaat
  if (item.includes("samosa")) return images.samosa
  if (
    item.includes("fries") ||
    item.includes("wedges") ||
    item.includes("onion rings")
  )
    return images.fries
  if (category === "Snacks") return images.samosa
  if (["Fresh Juices", "Healthy Juices"].includes(category))
    return images.juice
  if (category === "Lassi") return images.lassi
  if (category === "Mojitos") return images.mojito
  if (category === "Shakes") return images.shake
  if (category === "Tea & Coffee") return images.coffee
  if (category === "Desserts") return images.dessert
  return images.wrap
}

const slug = (value: string) =>
  value
    .toLowerCase()
    .replace(/&/g, "and")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "")

const rows: Array<[string, string, number, Partial<MenuItem>?]> = [
  [
    "Breakfast",
    "3pcs Idli Chutni Sambar",
    3,
    { vegetarian: true, popular: true },
  ],
  ["Breakfast", "2pcs Dosa Set", 3, { vegetarian: true, featured: true }],
  ["Breakfast", "Puttu Kadala Curry", 4, { vegetarian: true }],
  ["Breakfast", "2pcs Porota Moong Dal", 3, { vegetarian: true }],
  ["Breakfast", "2pcs Chapathi Egg Curry", 5],
  ["Breakfast", "3pcs Idiyappam + Moong Dal", 5, { vegetarian: true }],
  ["Breakfast", "Upma", 2, { vegetarian: true }],
  ...["Zinger", "Tikka", "Chicken Fillet", "Nuggets", "Mathafi", "Prawns"].map(
    (name) => ["Wraps", `${name} Wrap`, 10] as [string, string, number],
  ),
  ["Wraps", "Hot Dog Wrap", 9],
  ["Wraps", "Egg Wrap", 9],
  ["Wraps", "Kabab / Beef & Chicken Wrap", 9],
  ["Parota", "Zinger Porota", 7, { popular: true }],
  ["Parota", "Tikka Porota", 6],
  ["Parota", "Omelette / Boiled Egg Porota", 4],
  ["Parota", "Chi Chilly Porota", 5],
  ["Parota", "Falafel Porota", 4, { vegetarian: true }],
  ["Parota", "Oman Chips Porota", 3, { vegetarian: true }],
  ["Parota", "Hot Dog Porota", 4],
  ["Parota", "Franchisco Porota", 6],
  ["Parota", "Prawns Porota", 6],
  ["Parota", "Nuggets Porota", 5],
  ["Parota", "Vegetable Porota", 5, { vegetarian: true }],
  ["Parota", "Cheese Porota", 3, { vegetarian: true }],
  ["Parota", "Chicken Kabab Porota", 5],
  ["Parota", "Beef / Kabab Porota", 5],
  ...[
    "Zinger",
    "Chicken / Beef",
    "Chicken Fillet",
    "Nuggets",
    "Lulu",
    "Mathafi",
    "Tikka",
    "Prawns",
  ].map(
    (name) =>
      [
        "Club Sandwich",
        `${name} Club`,
        name === "Chicken / Beef" ? 10 : 12,
      ] as [string, string, number],
  ),
  ["Club Sandwich", "Hot Dog Club", 10],
  ["Club Sandwich", "Egg Club", 10],
  ["Club Sandwich", "Veg. Club", 11, { vegetarian: true }],
  ["Club Sandwich", "Mix Club", 12],
  ["Burgers", "Chicken / Beef Burger", 7, { popular: true }],
  ["Burgers", "Vegetable Burger", 7, { vegetarian: true }],
  ["Burgers", "Chicken Fillet Burger", 9],
  ["Burgers", "Fish Fillet Burger", 9],
  [
    "Burgers",
    "Zinger Burger",
    9,
    { featured: true, popular: true, badge: "POPULAR" },
  ],
  ["Burgers", "Nuggets Burger", 8],
  ["Burgers", "Khaleej Burger", 9],
  ["Burgers", "Chicken Tikka Burger", 8],
  ["Burgers", "Prawn Burger", 9],
  ["Burgers", "Cajun Burger", 9],
  ["Burgers", "Mathafi Burger", 9],
  ["Burgers", "Chicken Lemon Burger", 9],
  ["Special Burgers", "Chicken / Beef Double Burger", 11],
  ["Special Burgers", "Mega Zinger Burger", 12, { featured: true }],
  ["Special Burgers", "King Burger Chicken / Beef", 12],
  ["Shawarma", "Shawarma Normal", 5, { popular: true, featured: true }],
  ["Shawarma", "Shawarma Spicy", 5],
  ["Shawarma", "Jumbo Shawarma", 8],
  ...[
    "Chicken",
    "Vegetable",
    "Chicken Fillet",
    "Fish Fillet",
    "Nuggets",
    "Khaleej",
    "Tikka",
  ].map(
    (name) =>
      [
        "Combos",
        `${name} Combo`,
        8,
        { badge: "COMBO" },
      ] as [string, string, number, Partial<MenuItem>],
  ),
  ...[
    "Zinger",
    "Cajun",
    "Chicken Lemon",
    "Mathafi",
    "Kabab / Beef & Chicken",
  ].map(
    (name) =>
      [
        "Combos",
        `${name} Combo`,
        9,
        { badge: "COMBO" },
      ] as [string, string, number, Partial<MenuItem>],
  ),
  ["Chaat", "Pani Puri", 6, { vegetarian: true }],
  ["Chaat", "Samosa Chaat", 8, { vegetarian: true }],
  ["Chaat", "Vada Pav", 6, { vegetarian: true, popular: true }],
  ["Chaat", "Chana Chaat", 10, { vegetarian: true }],
  ["Chaat", "Aloo Tikki", 8, { vegetarian: true }],
  ["Snacks", "Chi / Veg Samosa", 1, { badge: "AED 1" }],
  ["Snacks", "Aloo Samosa", 1, { vegetarian: true, badge: "AED 1" }],
  ["Snacks", "Chicken Roll", 2],
  ["Snacks", "Banana Fry", 1.5, { vegetarian: true }],
  ["Snacks", "Veg. Noodles", 4, { vegetarian: true }],
  ["Snacks", "Chicken Noodles", 5],
  ["Snacks", "Pasta", 5],
  ["Snacks", "Lemon Water", 2, { vegetarian: true }],
  ["Snacks", "Roohafza", 2, { vegetarian: true }],
  ["Snacks", "Ice Cream Cone", 2, { vegetarian: true }],
  ["Snacks", "French Fries (Plate)", 5, { vegetarian: true }],
  ["Snacks", "Wedges Potato (Plate)", 6, { vegetarian: true }],
  ["Snacks", "Onion Rings (Plate)", 6, { vegetarian: true }],
  ...["Avocado", "Mango", "Orange", "Watermelon", "Pineapple"].map(
    (name) =>
      [
        "Fresh Juices",
        name,
        6,
        {
          priceVariants: [
            { label: "Small", price: 6 },
            { label: "Medium", price: 8 },
            { label: "Large", price: 10 },
          ],
        },
      ] as [string, string, number, Partial<MenuItem>],
  ),
  ["Tea & Coffee", "Kadak Tea", 1, { badge: "AED 1", featured: true }],
  ["Tea & Coffee", "Fresh Milk Tea", 2],
  ["Tea & Coffee", "Black Tea", 1, { badge: "AED 1" }],
  ["Tea & Coffee", "Green Tea", 1, { badge: "AED 1" }],
  [
    "Tea & Coffee",
    "Milk Coffee",
    2,
    {
      priceVariants: [
        { label: "Regular", price: 2 },
        { label: "Large", price: 3 },
      ],
    },
  ],
  ...["Power Booster", "Iron Booster", "ABC", "By Five", "Liver Care"].map(
    (name) => ["Healthy Juices", name, 12] as [string, string, number],
  ),
  ["Lassi", "Sweet Lassi", 5],
  ["Lassi", "Mango Lassi", 5, { popular: true }],
  ["Lassi", "Strawberry Lassi", 5],
  ["Lassi", "Avocado Lassi", 6],
  ...[
    "Strawberry",
    "Blue Lagoon",
    "Watermelon",
    "Passion Fruit",
    "Blue Berry",
    "Lemon",
    "Kiwi",
    "Green Apple",
  ].map(
    (name) => ["Mojitos", `${name} Mojito`, 10] as [string, string, number],
  ),
  ...[
    "Chocolate",
    "Vanilla",
    "Strawberry",
    "Cold Coffee",
    "Snickers",
    "Nutella",
    "Kinder",
  ].map(
    (name) =>
      [
        "Shakes",
        `${name} Shake`,
        7,
        {
          priceVariants: [
            { label: "Regular", price: 7 },
            { label: "Large", price: 9 },
          ],
        },
      ] as [string, string, number, Partial<MenuItem>],
  ),
  [
    "Shakes",
    "Oreo Milkshake",
    7,
    {
      priceVariants: [
        { label: "Regular", price: 7 },
        { label: "Large", price: 8 },
      ],
    },
  ],
  [
    "Shakes",
    "KitKat Shake",
    7,
    {
      priceVariants: [
        { label: "Regular", price: 7 },
        { label: "Large", price: 8 },
      ],
    },
  ],
  ["Desserts", "Mix Ice Cream", 10],
  ["Desserts", "Fruit Salad with Ice Cream", 10],
  ["Desserts", "Royal Falooda", 10, { featured: true }],
  ["Desserts", "Strawberry Falooda", 10],
  ["Desserts", "Mango Falooda", 10],
]

export const menu: MenuItem[] = rows.map(
  ([category, name, price, extras = {}]) => ({
    id: slug(`${category}-${name}`),
    name,
    category,
    price,
    image: imageFor(category, name),
    available: true,
    ...extras,
  }),
)

export const categories = [
  "All",
  ...Array.from(new Set(menu.map((item) => item.category))),
]

export const formatPrice = (price: number) =>
  Number.isInteger(price) ? price.toFixed(0) : price.toFixed(2)

/** Responsive srcSet for the Unsplash-hosted photos used across the site. */
export const imageSrcSet = (url: string, widths = [480, 800, 1200]) =>
  widths.map((w) => `${url.replace(/w=\d+/, `w=${w}`)} ${w}w`).join(", ")
