// Builds the site, pre-renders the React app into static HTML (for search engines,
// AI crawlers and no-JS visitors) and writes robots.txt, llms.txt and sitemap.xml.
// Usage:  SITE_URL=https://your-domain.com node build.mjs        (folder → dist/)
//         SINGLE=1 SITE_URL=https://your-domain.com node build.mjs (one file → dist-single/)
import { build } from "vite"
import react from "@vitejs/plugin-react"
import fs from "node:fs"
import path from "node:path"
import { pathToFileURL } from "node:url"

const single = process.env.SINGLE === "1"
const siteUrl = (process.env.SITE_URL || "").replace(/\/+$/, "")
const out = single ? "dist-single" : "dist"
const esc = (v) => String(v).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/"/g, "&quot;")

await build({ configFile: "vite.prod.config.ts", logLevel: "warn" })
await build({
  configFile: false,
  logLevel: "warn",
  plugins: [react()],
  build: {
    ssr: "src/entry-server.tsx",
    outDir: "dist-ssr",
    emptyOutDir: true,
    assetsInlineLimit: single ? 100_000_000 : 0,
  },
  base: single ? "./" : "/",
})

const m = await import(pathToFileURL(path.resolve("dist-ssr/entry-server.js")).href)
const { SEO, BUSINESS, menu, categories, formatPrice, buildJsonLd } = m
const app = m.render()

const head = [
  `<title>${esc(SEO.title)}</title>`,
  `<meta name="description" content="${esc(SEO.description)}" />`,
  `<link rel="icon" type="image/svg+xml" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='14' fill='%238b5e3c'/%3E%3Ctext x='32' y='44' font-family='Georgia,serif' font-size='36' font-weight='700' text-anchor='middle' fill='%23f4ecdf'%3EM%3C/text%3E%3C/svg%3E" />`,
  `<meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1" />`,
  siteUrl && `<link rel="canonical" href="${siteUrl}/" />`,
  `<meta property="og:type" content="restaurant.restaurant" />`,
  `<meta property="og:site_name" content="${BUSINESS.name}" />`,
  `<meta property="og:locale" content="en_AE" />`,
  `<meta property="og:title" content="${esc(SEO.ogTitle)}" />`,
  `<meta property="og:description" content="${esc(SEO.ogDescription)}" />`,
  siteUrl && `<meta property="og:url" content="${siteUrl}/" />`,
  `<meta property="og:image" content="${esc(SEO.ogImage)}" />`,
  `<meta name="twitter:card" content="summary_large_image" />`,
  `<meta name="twitter:title" content="${esc(SEO.ogTitle)}" />`,
  `<meta name="twitter:description" content="${esc(SEO.ogDescription)}" />`,
  `<meta name="twitter:image" content="${esc(SEO.ogImage)}" />`,
  `<script type="application/ld+json">${JSON.stringify(buildJsonLd(siteUrl || undefined)).replace(/</g, "\\u003c")}</script>`,
]
  .filter(Boolean)
  .join("\n    ")

const cats = categories.slice(1)
const noscript = `<noscript>
      <h2>Master Cafe menu</h2>
      <p>JavaScript is needed for the cart. You can still order by calling ${BUSINESS.phone.replace("+971", "0")} or on WhatsApp: https://wa.me/971554769522</p>
      ${cats
        .map(
          (c) =>
            `<h3>${esc(c)}</h3><ul>${menu
              .filter((i) => i.category === c)
              .map((i) => `<li>${esc(i.name)}: AED ${formatPrice(i.price)}${i.priceVariants ? " (" + i.priceVariants.map((v) => `${esc(v.label)} AED ${formatPrice(v.price)}`).join(", ") + ")" : ""}</li>`)
              .join("")}</ul>`,
        )
        .join("\n      ")}
    </noscript>`

const file = path.join(out, "index.html")
let html = fs.readFileSync(file, "utf8")
for (const [marker, value] of [["<!--head-tags-->", head], ["<!--app-html-->", app], ["<!--noscript-menu-->", noscript]]) {
  if (!html.includes(marker)) throw new Error(`Marker missing in built HTML: ${marker}`)
  html = html.replace(marker, () => value)
}
fs.writeFileSync(file, html)

fs.writeFileSync(
  path.join(out, "robots.txt"),
  [
    "User-agent: *",
    "Allow: /",
    "",
    "# AI search and answer-engine crawlers are welcome",
    ...["GPTBot", "OAI-SearchBot", "ChatGPT-User", "ClaudeBot", "Claude-SearchBot", "Claude-User", "PerplexityBot", "Google-Extended", "Applebot-Extended"].flatMap((b) => [`User-agent: ${b}`, "Allow: /", ""]),
    siteUrl ? `Sitemap: ${siteUrl}/sitemap.xml` : "# Sitemap: add once SITE_URL is known",
    "",
  ].join("\n"),
)

const lines = [
  `# ${BUSINESS.name}`,
  "",
  `> Affordable burgers, shawarma, Kerala-style breakfast, snacks, fresh juices and cafe drinks inside GSeven Hypermarket, Al Muteena, Deira, Dubai. Free local delivery. Orders via WhatsApp.`,
  "",
  "## Facts",
  `- Address: ${BUSINESS.street}, ${BUSINESS.locality}, ${BUSINESS.region}, UAE`,
  `- Phone / WhatsApp: ${BUSINESS.phoneDisplay} (${BUSINESS.phone})`,
  "- Delivery: free local delivery in Al Muteena and Deira; pickup also available",
  `- Menu: ${menu.length} items in ${cats.length} categories; prices from AED 1`,
  "- Opening hours: not published on the website",
  siteUrl ? `- Website: ${siteUrl}/` : "",
  "",
  "## Menu",
  ...cats.flatMap((c) => [`### ${c}`, ...menu.filter((i) => i.category === c).map((i) => `- ${i.name}: AED ${formatPrice(i.price)}${i.priceVariants ? " (" + i.priceVariants.map((v) => `${v.label} AED ${formatPrice(v.price)}`).join(", ") + ")" : ""}`), ""]),
].filter((l, i, a) => !(l === "" && a[i - 1] === ""))
fs.writeFileSync(path.join(out, "llms.txt"), lines.join("\n") + "\n")

if (siteUrl)
  fs.writeFileSync(
    path.join(out, "sitemap.xml"),
    `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n  <url><loc>${siteUrl}/</loc><changefreq>weekly</changefreq><priority>1.0</priority></url>\n</urlset>\n`,
  )
// Branded 404 page. Hosts such as Netlify, Cloudflare Pages and Vercel serve /404.html
// with a real 404 status for unknown URLs. Plain static servers need this set up by hand.
fs.writeFileSync(
  path.join(out, "404.html"),
  `<!doctype html>
<html lang="en"><head><meta charset="UTF-8" /><meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Page not found | ${BUSINESS.name}</title><meta name="robots" content="noindex" />
<style>body{margin:0;min-height:100vh;display:grid;place-items:center;padding:24px;background:#f4ecdf;color:#352319;font-family:"DM Sans",Arial,sans-serif;text-align:center}main{max-width:480px}h1{margin:0 0 12px;font-family:"Playfair Display",Georgia,serif;font-size:clamp(40px,10vw,64px);line-height:1}p{margin:0 0 28px;color:#66503f;line-height:1.7}a{display:inline-flex;min-height:44px;align-items:center;padding:0 22px;background:#8b5e3c;color:#fff;font-weight:650;text-decoration:none}a:focus-visible{outline:2px solid #352319;outline-offset:3px}</style></head>
<body><main><h1>Page not found</h1><p>We couldn't find the page you were looking for. The menu and ordering are on our home page.</p><a href="/">Back to ${BUSINESS.name}</a></main></body></html>
`,
)

// Security headers for hosts that read a _headers file (Netlify, Cloudflare Pages).
// The CSP matches what the site really loads: own scripts/styles, Google Fonts, Unsplash images.
fs.writeFileSync(
  path.join(out, "_headers"),
  [
    "/*",
    "  X-Content-Type-Options: nosniff",
    "  Referrer-Policy: strict-origin-when-cross-origin",
    "  Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=()",
    "  Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data: https://images.unsplash.com; connect-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'",
    "",
    "/assets/*",
    "  Cache-Control: public, max-age=31536000, immutable",
    "",
  ].join("\n"),
)

console.log(`Built ${out}/ (${(fs.statSync(file).size / 1024).toFixed(0)} KB index.html)${siteUrl ? "" : "  [no SITE_URL: canonical/sitemap omitted]"}`)
